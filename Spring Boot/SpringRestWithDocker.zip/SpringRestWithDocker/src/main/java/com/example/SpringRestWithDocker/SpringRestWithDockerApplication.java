package com.example.SpringRestWithDocker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestWithDockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestWithDockerApplication.class, args);
	}

}
